var Premio = require('../../models/premio')

// Devolve a lista de prémios apenas com os campos "year" e "category";
module.exports.listar = () => {
    return Premio
        .find({}, {year:true, category:true})
        .sort({year: -1})
        .exec()
}

//Devolve a informação completa de um prémio
module.exports.consultar = pid => {
    return Premio
        .findOne({_id: pid})
        .exec()
}

//Devolve a lista de prémios que tenham o campo "category" com o valor "YYY";
module.exports.listarCategoria= category => {
    return Premio
        .find({category: category})
        .sort({year: -1})
        .exec()
}

/*Devolve a lista de prémios que tenham o campo "category" com o valor "YYY" 
e o campo "year" com um valor superior a "AAAA";*/
module.exports.listarCategAno= (category,year) => {
    return Premio
        .find({category: category}, {year: year})
        .sort({year: -1})
        .exec()
}

/*Devolve uma lista ordenada alfabeticamente por nome dos laureados 
com os campos correspondentes ao nome, ano do prémio e categoria.*/
module.exports.listarLaureados= laureates => {
    return Premio
        .find({}, laureates)
        .sort({firstname: -1})
        .exec()
}


