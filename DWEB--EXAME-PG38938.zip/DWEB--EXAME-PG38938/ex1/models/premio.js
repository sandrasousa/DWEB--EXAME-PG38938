var mongoose = require('mongoose')

var Schema = mongoose.Schema

var laureateSchema = new Schema({
    _id: {type: String, required: true},
    firstname: {type: String, required: true},
    surname: {type: String, required: true},
    motivation: {type: String},
    share: {type: String, required: true}
})

var PremioSchema = new Schema({
    year: {type: String, required: true},
    category: {type: String, required: true},
    overallMotivation: {type: String},
    laureates: [{laureateSchema}]
})

module.exports = mongoose.model('premios', PremioSchema)