var express = require('express')
var router = express.Router()
var Premio = require('../../controllers/api/premio')

//GET /api/premios
router.get('/', (req,res)=>{
    Premio.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem de premios.'))
})

//GET /api/premios/:pid
router.get('/:pid', (req,res)=>{
    Premio.consultar(req.params.pid)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta de premios.'))
})

//GET /api/premios?categoria=YYY
router.get('/categoria/:c', (req,res)=>{
    Premio.listarCategoria(req.params.c)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de categorias.'))
})

//GET /api/premios?categoria=YYY&data=AAAA

router.get('/categoria/:c&data/:a', (req,res)=>{
    Premio.listarCategAno(req.params.c, req.params.a)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de categorias.'))
})

//GET /api/laureados
router.get('/laureados', (req,res)=>{
    Premio.listarLaureados()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem dos laureados.'))
})


module.exports = router;