var express = require('express');
var router = express.Router();
var axios = require('axios')

/* GET home page. */
router.get('/',(req,res)=>{
  axios.get("http://clav-test.di.uminho.pt/api/classes")
    .then(resposta => {
      res.render('index', {classes:resposta.data });
    })
    .catch(erro => {
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
})

router.get('/:c',(req,res)=>{
  axios.get("http://clav-test.di.uminho.pt/api/classes/c" + req.params.c)
    .then(resposta=>{
            axios.get("http://clav-test.di.uminho.pt/api/classes/c" + req.params.c + "/descendencia")
            .then(resposta2=>{
                parent = req.params.c
                var result = parent.split(".")
                var newparent = ""
                for (index = 0; index < result.length-1; ++index) {
                    if(index > 0)
                        newparent= newparent+"."+ result[index]
                    else
                        newparent= newparent+ result[index]
                }
                res.render('classe', {data:{parent: newparent, classe:resposta.data[0], childs: resposta2.data}});
            })
            .catch(erro => {
              res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
            })
    })
    .catch(erro => {
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
})

module.exports = router;
